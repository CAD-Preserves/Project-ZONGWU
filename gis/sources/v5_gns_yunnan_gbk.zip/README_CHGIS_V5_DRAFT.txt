CHGIS V5

PRE-PUBLICATION DRAFT  (Sep 2010)

China Historical Geographic Information System Version 5.0
(c) Harvard Yenching Institute 2010
------------------
For non-commercial academic purposes only.
Use of this data implies agreement with the End User License Agreement available online here:
http://www.fas.harvard.edu/~chgis/data/chgis/downloads/v4/EULA.html

------------------
NOTE on this draft:  

This is a pre-publication DRAFT for testing and evaluation only.


