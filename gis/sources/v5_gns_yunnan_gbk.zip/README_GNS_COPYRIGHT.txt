﻿"GNS Country Files, China."
Geographic Names Database
(c) 2000 U.S. Board on Geographic Names
Public Domain Dataset

------------------

CHGIS Version 5 [2010] GNS Files Metadata

Language Encoding:  Chinese GB 2312
Projection:  PCS Gauss Kruger Xian 1980 Zone 19

Toponymic information is based on the Geographic Names Data Base,
containing official standard names approved by the United States Board on 
Geographic Names and maintained by the National Geospatial-Intelligence Agency.
More information is available at the Maps and Geodata link at www.nga.mil.

CHGIS Editor's Note:  Chinese Placenames in GNS files were extracted from 
numerous map sources.  Romanizations are mixed (Pinyin, Wade-Giles, ad hoc).
Hierarchical Administrative Unit information, found in all of the FIELDS to 
the right of NM_ASCII (in the attribute table) are derived from spatial joins
with COUNTY level units, circa 1991, and match the National Standard Codes
(GuoBiao Codes) in the publication GBT / 2260 1991.  Therefore the data can be
sorted by Prefectural Level Unit (using the PREF_ID field) or by County Level
Unit (using the CNTY_ID field).  A digital table of the GBT 2260 codes can be
downloaded from CHGIS.

-------------------

Download GNS data:
http://earth-info.nga.mil/gns/html/namefiles.htm

Documentation on GNS FIELD NAMES:
http://earth-info.nga.mil/gns/html/help.htm

GNS website:
http://earth-info.nga.mil/gns/html/

Download GBT 2260 codes:
http://www.people.fas.harvard.edu/~chgis/work/downloads/faqs/gb_1991_faq.html


------------------

CHGIS Processing of GNS files

CHGIS used the 1990 CITAS polygons to spatially join administrative jurisdiction data to the GNS point features. We also clipped out many of the FIELDS from the original GNS files that contained NULL values. The result are thirty separate GIS layers, one for each province (circa 1990). All of the features found in the Provincial GIS layer have been stamped with their parent jurisdictions at the County and the Prefecture levels. The jurisdiction information includes Placenames and National Standard Geographic Codes.  See GuoBiao Table 2260 1991 for more information on GB Codes:  http://www.people.fas.harvard.edu/~chgis/work/downloads/faqs/gb_1991_faq.html

For example, the feature called Yiwu, which has no jurisdictional information in the original GNS file, contains the following information in the CHGIS GNS China 1990 Placenames in Yunnan layer:

    * PROV_PY = YUNNAN (Province Name in Pinyin)
    * PREF_ID = 532800 (Prefecture Level Guobiao 2260 -1991 Code Number)
    * PREF_PY = Xishuangbanna Daizu Zizhizhou (Prefecture Name in Pinyin)
    * CNTY_CH = 勐腊县 (County Name in GBK Encoded Chinese Characters)
    * CNTY_PY = Mengla Xian (County Name in Pinyin)
    * CNTY_ID = 532823 (County Level Guobiao 2260 - 1991 Code Number) 